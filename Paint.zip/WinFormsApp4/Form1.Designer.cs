﻿namespace WinFormsApp4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.brButton = new System.Windows.Forms.Button();
            this.oButton = new System.Windows.Forms.Button();
            this.allButton = new System.Windows.Forms.Button();
            this.bButton = new System.Windows.Forms.Button();
            this.rButton = new System.Windows.Forms.Button();
            this.yButton = new System.Windows.Forms.Button();
            this.blButton = new System.Windows.Forms.Button();
            this.gButton = new System.Windows.Forms.Button();
            this.pButton = new System.Windows.Forms.Button();
            this.wButton = new System.Windows.Forms.Button();
            this.lbButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Location = new System.Drawing.Point(255, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1229, 896);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(12, 733);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(237, 56);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(12, 671);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(237, 56);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.brButton);
            this.panel1.Controls.Add(this.oButton);
            this.panel1.Controls.Add(this.allButton);
            this.panel1.Controls.Add(this.bButton);
            this.panel1.Controls.Add(this.rButton);
            this.panel1.Controls.Add(this.yButton);
            this.panel1.Controls.Add(this.blButton);
            this.panel1.Controls.Add(this.gButton);
            this.panel1.Controls.Add(this.pButton);
            this.panel1.Controls.Add(this.wButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 187);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(260, 172);
            this.panel1.TabIndex = 3;
            // 
            // brButton
            // 
            this.brButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.brButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.brButton.Location = new System.Drawing.Point(154, 78);
            this.brButton.Name = "brButton";
            this.brButton.Size = new System.Drawing.Size(40, 40);
            this.brButton.TabIndex = 13;
            this.brButton.UseVisualStyleBackColor = false;
            this.brButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // oButton
            // 
            this.oButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.oButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.oButton.Location = new System.Drawing.Point(108, 78);
            this.oButton.Name = "oButton";
            this.oButton.Size = new System.Drawing.Size(40, 40);
            this.oButton.TabIndex = 12;
            this.oButton.UseVisualStyleBackColor = false;
            this.oButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // allButton
            // 
            this.allButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("allButton.BackgroundImage")));
            this.allButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.allButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.allButton.Location = new System.Drawing.Point(16, 124);
            this.allButton.Name = "allButton";
            this.allButton.Size = new System.Drawing.Size(224, 40);
            this.allButton.TabIndex = 11;
            this.allButton.UseVisualStyleBackColor = true;
            this.allButton.Click += new System.EventHandler(this.allButton_Click);
            // 
            // bButton
            // 
            this.bButton.BackColor = System.Drawing.Color.Black;
            this.bButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bButton.Location = new System.Drawing.Point(62, 21);
            this.bButton.Name = "bButton";
            this.bButton.Size = new System.Drawing.Size(40, 40);
            this.bButton.TabIndex = 10;
            this.bButton.UseVisualStyleBackColor = false;
            this.bButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // rButton
            // 
            this.rButton.BackColor = System.Drawing.Color.Red;
            this.rButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rButton.Location = new System.Drawing.Point(108, 21);
            this.rButton.Name = "rButton";
            this.rButton.Size = new System.Drawing.Size(40, 40);
            this.rButton.TabIndex = 9;
            this.rButton.UseVisualStyleBackColor = false;
            this.rButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // yButton
            // 
            this.yButton.BackColor = System.Drawing.Color.Yellow;
            this.yButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yButton.Location = new System.Drawing.Point(154, 21);
            this.yButton.Name = "yButton";
            this.yButton.Size = new System.Drawing.Size(40, 40);
            this.yButton.TabIndex = 8;
            this.yButton.UseVisualStyleBackColor = false;
            this.yButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // blButton
            // 
            this.blButton.BackColor = System.Drawing.Color.Blue;
            this.blButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.blButton.Location = new System.Drawing.Point(200, 21);
            this.blButton.Name = "blButton";
            this.blButton.Size = new System.Drawing.Size(40, 40);
            this.blButton.TabIndex = 7;
            this.blButton.UseVisualStyleBackColor = false;
            this.blButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // gButton
            // 
            this.gButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.gButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gButton.Location = new System.Drawing.Point(16, 78);
            this.gButton.Name = "gButton";
            this.gButton.Size = new System.Drawing.Size(40, 40);
            this.gButton.TabIndex = 6;
            this.gButton.UseVisualStyleBackColor = false;
            this.gButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // pButton
            // 
            this.pButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.pButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pButton.Location = new System.Drawing.Point(62, 78);
            this.pButton.Name = "pButton";
            this.pButton.Size = new System.Drawing.Size(40, 40);
            this.pButton.TabIndex = 5;
            this.pButton.UseVisualStyleBackColor = false;
            this.pButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // wButton
            // 
            this.wButton.BackColor = System.Drawing.Color.White;
            this.wButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.wButton.Location = new System.Drawing.Point(16, 21);
            this.wButton.Name = "wButton";
            this.wButton.Size = new System.Drawing.Size(40, 40);
            this.wButton.TabIndex = 4;
            this.wButton.UseVisualStyleBackColor = false;
            this.wButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // lbButton
            // 
            this.lbButton.BackColor = System.Drawing.Color.White;
            this.lbButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("lbButton.BackgroundImage")));
            this.lbButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lbButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbButton.Location = new System.Drawing.Point(100, 22);
            this.lbButton.Name = "lbButton";
            this.lbButton.Size = new System.Drawing.Size(60, 60);
            this.lbButton.TabIndex = 14;
            this.lbButton.UseVisualStyleBackColor = false;
            this.lbButton.Click += new System.EventHandler(this.lbButton_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.trackBar1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(260, 187);
            this.panel2.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(258, 52);
            this.label1.TabIndex = 1;
            this.label1.Text = "Розмір пензла";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // trackBar1
            // 
            this.trackBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.trackBar1.Location = new System.Drawing.Point(0, 105);
            this.trackBar1.Maximum = 30;
            this.trackBar1.Minimum = 10;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(258, 80);
            this.trackBar1.TabIndex = 0;
            this.trackBar1.Value = 10;
            this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.clearButton);
            this.panel3.Controls.Add(this.saveButton);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(260, 896);
            this.panel3.TabIndex = 14;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lbButton);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 359);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(260, 106);
            this.panel4.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1484, 896);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox pictureBox1;
        private Button clearButton;
        private Button saveButton;
        private Panel panel1;
        private Button lbButton;
        private Button brButton;
        private Button oButton;
        private Button allButton;
        private Button bButton;
        private Button rButton;
        private Button yButton;
        private Button blButton;
        private Button gButton;
        private Button pButton;
        private Button wButton;
        private Panel panel2;
        private Label label1;
        private TrackBar trackBar1;
        private ColorDialog colorDialog1;
        private SaveFileDialog saveFileDialog1;
        private Panel panel3;
        private Panel panel4;
    }
}